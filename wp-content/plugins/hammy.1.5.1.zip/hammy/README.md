Hammy
=====

Hammy takes your regular content images (only within posts and pages, not custom post types) and regenerates a number of smaller sized images. When a person visits your website, it then automatically provides them with the most appropriate image (or the smallest one possible). This makes for a better experience, especially on mobile. This uses the new WP 3.5 image code.

See: http://wordpress.org/plugins/hammy/

Repo comments:

* Pull requests welcome (don't put more then one type of change in a single PR)
* Issues welcome (be clear, concise)
