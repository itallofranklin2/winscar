
	/**
	 * Plugin construct function
	 */
	function Banner(elem, options) {
		this.$elem = $(elem);
		this.options = options;
	}
