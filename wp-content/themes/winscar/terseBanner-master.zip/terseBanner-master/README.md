# terseBanner

### [View Online example...](https://happyfreelife.github.io/terseBanner/example/example.html)
